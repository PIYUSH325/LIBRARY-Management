const express = require('express');
const multer = require('multer');
const path = require('path');
const mysql = require('mysql2');

const app = express();
const port = 3000;

// Create MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root', // Replace with your MySQL root password
    database: 'library'
});

// Connect to MySQL
connection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL');
});

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Please upload only images.'));
        }
    }
});

// Middleware
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Endpoint to add a book
app.post('/books', upload.single('bookImage'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    const { title, author, genre } = req.body;
    const imagePath = req.file.filename;

    // Inserting book details into the database
    const insertQuery = `INSERT INTO books (title, author, genre, image_path) VALUES (?, ?, ?, ?)`;
    connection.query(insertQuery, [title, author, genre, imagePath], (error, results) => {
        if (error) {
            console.error('Error inserting into MySQL: ' + error);
            return res.status(500).send('Error inserting data into MySQL');
        }
        return res.json({ success: true });
    });
});

// Endpoint to get all books
app.get('/books', (req, res) => {
    // Query to retrieve all books
    const selectQuery = 'SELECT * FROM books';
    connection.query(selectQuery, (error, results) => {
        if (error) {
            console.error('Error fetching books: ' + error);
            return res.status(500).send('Error fetching books');
        }
        return res.json(results); // Send the results back as JSON
    });
});

// Endpoint to serve the main HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html')); // Adjusted for your file structure
});

app.delete('/books/:id', (req, res) => {
    const bookId = req.params.id;

    // SQL query to delete the book from the database
    const sql = 'DELETE FROM books WHERE id = ?';
    
    connection.query(sql, [bookId], (err, result) => {
        if (err) {
            return res.status(500).send('Error deleting book: ' + err);
        }
        if (result.affectedRows === 0) {
            return res.status(404).send('Book not found');
        }
        res.status(200).send('Book deleted successfully');
    });
});


// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

// Close the database connection gracefully on server exit
process.on('SIGINT', () => {
    connection.end(err => {
        if (err) {
            console.error('Error ending MySQL connection: ' + err);
        }
        console.log('MySQL connection closed');
        process.exit(0);
    });
});
